# NetOps Command Center

> A modern, web-based network device management platform for ISP infrastructure with REST API integration

![Docker](https://img.shields.io/badge/Docker-Ready-blue)
![Python](https://img.shields.io/badge/Python-3.11-green)
![License](https://img.shields.io/badge/License-MIT-yellow)

## 🚀 Features

- **Beautiful Web Interface** - Cyberpunk-inspired UI with smooth animations
- **Multi-Vendor Support** - Ciena, Brocade (CES/ICX/FWS), Alcatel 7210
- **SSH & Telnet** - Full protocol support
- **TACACS+ Authentication** - Enterprise-ready with enable mode support
- **REST API** - Complete API for automation and integration
- **Batch Operations** - Execute commands across multiple devices
- **Docker Ready** - One-command deployment
- **Python SDK** - Easy integration library

## 📸 Screenshots

### Main Interface
*Beautiful cyberpunk-inspired design with electric cyan and magenta gradients*

### Batch Operations
*Execute commands across your entire infrastructure simultaneously*

## 🎯 Quick Start

### Using Docker (Recommended)

```bash
# Clone the repository
git clone https://github.com/your-username/netops-command-center.git
cd netops-command-center

# Start the application
docker-compose up -d

# Access the interface
open http://localhost:5000
```

### Manual Installation

```bash
# Install dependencies
pip install -r requirements.txt

# Start the server
python3 api_server.py

# Access the interface
open http://localhost:5000
```

## 📚 Documentation

- **[Docker Deployment](DOCKER_README.md)** - Complete Docker setup guide
- **[API Integration](API_INTEGRATION.md)** - REST API documentation with examples
- **[Troubleshooting](TROUBLESHOOTING.md)** - Common issues and solutions
- **[Design Specification](DESIGN_SPEC.md)** - UI/UX design details

## 🔌 Supported Devices

| Vendor | Model | Status |
|--------|-------|--------|
| Ciena | Metro Ethernet Platforms | ✅ Supported |
| Brocade | CES (Carrier Ethernet Service) | ✅ Supported |
| Brocade | ICX (Campus/Datacenter) | ✅ Supported |
| Brocade | FWS (FastIron Workgroup) | ✅ Supported |
| Alcatel-Lucent | 7210 SAR | ✅ Supported |

## 💻 API Usage

### Python SDK

```python
from netops_sdk import NetOpsClient, DeviceConfig

# Initialize client
client = NetOpsClient("http://localhost:5000")

# Execute commands
result = client.execute(
    ip="192.168.1.1",
    username="admin",
    password="password",
    device_type="brocade_icx",
    use_basic_commands=True
)

print(result['results'])
```

### cURL

```bash
curl -X POST http://localhost:5000/api/execute \
  -H "Content-Type: application/json" \
  -d '{
    "ip_address": "192.168.1.1",
    "username": "admin",
    "password": "password",
    "device_type": "brocade_icx",
    "use_basic_commands": true
  }'
```

See [API_INTEGRATION.md](API_INTEGRATION.md) for complete API documentation.

## 🏗️ Architecture

```
┌─────────────────┐
│   Web Browser   │
│   (Frontend)    │
└────────┬────────┘
         │ HTTP/JSON
         │
┌────────▼────────┐
│  Flask API      │
│  (api_server.py)│
└────────┬────────┘
         │
┌────────▼────────┐
│  Device Manager │
│  (Python Core)  │
└────────┬────────┘
         │ SSH/Telnet
         │
┌────────▼────────┐
│ Network Devices │
└─────────────────┘
```

## 🔒 Security

**⚠️ Important for Production:**

1. **Enable HTTPS** - Never use HTTP in production
2. **Add Authentication** - Implement API key or OAuth
3. **Use Environment Variables** - Never commit credentials
4. **Enable Rate Limiting** - Prevent abuse
5. **Audit Logging** - Track all operations

See [Security Best Practices](DOCKER_README.md#security-best-practices) for details.

## 🛠️ Development

### Prerequisites

- Python 3.7+
- Docker & Docker Compose (for containerized deployment)
- Git

### Setup Development Environment

```bash
# Clone repository
git clone https://github.com/your-username/netops-command-center.git
cd netops-command-center

# Create virtual environment
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Run tests
python3 test_setup.py

# Start development server
python3 api_server.py
```

### Project Structure

```
netops-command-center/
├── api_server.py              # Flask API backend
├── network_device_manager.py  # Core device library
├── netops_sdk.py             # Python SDK
├── Dockerfile                # Container definition
├── docker-compose.yml        # Service orchestration
├── requirements.txt          # Python dependencies
├── static/
│   └── index.html           # Web interface
├── docs/                    # Documentation
└── tests/                   # Test suite
```

## 🧪 Testing

```bash
# Run diagnostic tests
python3 test_setup.py

# Test API endpoints
curl http://localhost:5000/api/health

# Test with real device (update credentials)
python3 device_cli.py -i 192.168.1.1 -u admin -p password -t brocade_icx --basic
```

## 📝 Usage Examples

### Single Device Query

```bash
python3 device_cli.py \
  -i 192.168.1.1 \
  -u admin \
  -p password \
  -t brocade_icx \
  --basic
```

### Batch Operations

```bash
python3 batch_manager.py \
  -f devices_config.json \
  --basic \
  --parallel 5
```

### Custom Commands

```bash
python3 device_cli.py \
  -i 192.168.1.1 \
  -u admin \
  -p password \
  -t ciena \
  -c "software show" "system show"
```

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- Built with [Flask](https://flask.palletsprojects.com/)
- SSH connectivity via [Paramiko](https://www.paramiko.org/)
- Designed for ISP network operations teams

## 📧 Support

- **Documentation**: See the `docs/` directory
- **Issues**: [GitHub Issues](https://github.com/your-username/netops-command-center/issues)
- **Discussions**: [GitHub Discussions](https://github.com/your-username/netops-command-center/discussions)

## 🗺️ Roadmap

- [ ] Multi-user authentication
- [ ] Persistent result storage (PostgreSQL)
- [ ] Scheduled command execution
- [ ] WebSocket real-time updates
- [ ] Command templates library
- [ ] SNMP support
- [ ] Additional vendor support
- [ ] Mobile app

## 📊 Stats

![GitHub stars](https://img.shields.io/github/stars/your-username/netops-command-center?style=social)
![GitHub forks](https://img.shields.io/github/forks/your-username/netops-command-center?style=social)
![GitHub issues](https://img.shields.io/github/issues/your-username/netops-command-center)

---

**Made with ❤️ for Network Operations Teams**
