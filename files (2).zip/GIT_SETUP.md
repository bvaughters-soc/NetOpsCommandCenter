# Git Repository Setup Guide

## Initial Repository Setup

### Step 1: Initialize Local Repository

```bash
cd /path/to/netops-command-center

# Initialize Git repository
git init

# Add all files
git add .

# Create initial commit
git commit -m "Initial commit: NetOps Command Center"
```

### Step 2: Create GitHub Repository

1. Go to [GitHub](https://github.com/new)
2. Create new repository named `netops-command-center`
3. **Don't initialize with README, .gitignore, or license** (we already have these)
4. Copy the repository URL

### Step 3: Connect to GitHub

```bash
# Add remote repository
git remote add origin https://github.com/YOUR_USERNAME/netops-command-center.git

# Push to GitHub
git branch -M main
git push -u origin main
```

## Repository Structure

Your repository should look like this:

```
netops-command-center/
├── .gitignore                 ✓ Excludes sensitive files
├── LICENSE                    ✓ MIT License
├── README.md                  ✓ Main documentation
├── DOCKER_README.md          ✓ Docker setup
├── API_INTEGRATION.md        ✓ API docs
├── TROUBLESHOOTING.md        ✓ Help guide
├── DESIGN_SPEC.md            ✓ Design docs
├── Dockerfile                ✓ Container definition
├── docker-compose.yml        ✓ Service config
├── requirements.txt          ✓ Dependencies
├── api_server.py             ✓ Flask backend
├── network_device_manager.py ✓ Core library
├── netops_sdk.py             ✓ Python SDK
├── device_cli.py             ✓ CLI tool
├── batch_manager.py          ✓ Batch processor
├── test_setup.py             ✓ Diagnostic tests
├── start_server.sh           ✓ Quick start
├── docker_start.sh           ✓ Docker launcher
├── static/
│   └── index.html           ✓ Web interface
└── devices_config.json       ✗ NOT committed (credentials!)
```

## Important: What NOT to Commit

**Never commit these files** (already in .gitignore):

- ❌ `tacacs_env.sh` - Contains credentials
- ❌ `devices_config.json` - Contains device passwords
- ❌ `credentials.json` - Any credential files
- ❌ `*.env` - Environment files
- ❌ `*.log` - Log files
- ❌ `*_results.json` - Output files

## Recommended Git Workflow

### Feature Development

```bash
# Create feature branch
git checkout -b feature/new-device-support

# Make changes
# ... edit files ...

# Commit changes
git add .
git commit -m "Add support for Juniper devices"

# Push to GitHub
git push origin feature/new-device-support

# Create Pull Request on GitHub
```

### Hotfix

```bash
# Create hotfix branch from main
git checkout main
git checkout -b hotfix/auth-bug

# Fix the bug
# ... edit files ...

# Commit and push
git add .
git commit -m "Fix authentication timeout issue"
git push origin hotfix/auth-bug

# Merge back to main after testing
```

### Tagging Releases

```bash
# Tag a release
git tag -a v1.0.0 -m "Version 1.0.0: Initial release"

# Push tags to GitHub
git push origin --tags

# Create release on GitHub with changelog
```

## Branch Strategy

### Recommended Branches:

- `main` - Production-ready code
- `develop` - Integration branch for features
- `feature/*` - New features
- `hotfix/*` - Urgent bug fixes
- `release/*` - Release preparation

### Branch Protection Rules (GitHub):

1. Require pull request reviews before merging
2. Require status checks to pass
3. Require branches to be up to date
4. Include administrators in protections

## Commit Message Guidelines

### Format:

```
<type>(<scope>): <subject>

<body>

<footer>
```

### Types:

- `feat` - New feature
- `fix` - Bug fix
- `docs` - Documentation changes
- `style` - Code style changes (formatting)
- `refactor` - Code refactoring
- `test` - Adding tests
- `chore` - Maintenance tasks

### Examples:

```bash
git commit -m "feat(api): Add support for Juniper devices"
git commit -m "fix(auth): Resolve TACACS timeout issue"
git commit -m "docs(readme): Update installation instructions"
git commit -m "chore(deps): Update Flask to 2.3.0"
```

## GitHub Repository Settings

### 1. Description
Add a clear description:
```
Modern web-based network device management platform for ISP infrastructure with REST API
```

### 2. Topics (Tags)
Add relevant topics:
- `network-automation`
- `isp-tools`
- `flask`
- `docker`
- `network-management`
- `ssh`
- `telnet`
- `rest-api`
- `brocade`
- `ciena`

### 3. Enable Features
- ✅ Issues - For bug reports and feature requests
- ✅ Discussions - For community Q&A
- ✅ Projects - For roadmap tracking
- ✅ Wiki - For extended documentation
- ✅ Actions - For CI/CD (optional)

### 4. Security
Enable:
- ✅ Dependabot alerts
- ✅ Code scanning alerts
- ✅ Secret scanning

## GitHub Actions (Optional CI/CD)

Create `.github/workflows/test.yml`:

```yaml
name: Tests

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Set up Python
        uses: actions/setup-python@v4
        with:
          python-version: '3.11'
      - name: Install dependencies
        run: pip install -r requirements.txt
      - name: Run tests
        run: python3 test_setup.py
```

## Collaboration

### For Contributors:

1. Fork the repository
2. Clone your fork: `git clone https://github.com/YOUR_USERNAME/netops-command-center.git`
3. Add upstream remote: `git remote add upstream https://github.com/ORIGINAL_OWNER/netops-command-center.git`
4. Create feature branch: `git checkout -b feature/my-feature`
5. Make changes and commit
6. Push to your fork: `git push origin feature/my-feature`
7. Create Pull Request on GitHub

### Keeping Fork Updated:

```bash
# Fetch upstream changes
git fetch upstream

# Merge upstream main into your local main
git checkout main
git merge upstream/main

# Push to your fork
git push origin main
```

## Repository Maintenance

### Regular Tasks:

```bash
# Update dependencies
pip list --outdated
pip install --upgrade <package>
pip freeze > requirements.txt
git add requirements.txt
git commit -m "chore(deps): Update dependencies"

# Clean up old branches
git branch -d feature/old-feature
git push origin --delete feature/old-feature

# Tag releases
git tag -a v1.1.0 -m "Version 1.1.0"
git push origin v1.1.0
```

## Backup Strategy

### Automated Backups:

1. **GitHub Actions** - Automatically backs up to GitHub
2. **Git Bundles** - Create local backups:
   ```bash
   git bundle create netops-backup.bundle --all
   ```
3. **Mirror Repository** - Create a mirror on GitLab or Bitbucket

## Documentation in Repository

Keep documentation up-to-date:

```
docs/
├── README.md                 # Overview
├── INSTALLATION.md          # Setup guide
├── API.md                   # API reference
├── CONTRIBUTING.md          # Contributor guide
├── CHANGELOG.md             # Version history
└── TROUBLESHOOTING.md       # Common issues
```

## Release Checklist

Before creating a release:

- [ ] Update version numbers
- [ ] Update CHANGELOG.md
- [ ] Run all tests
- [ ] Update documentation
- [ ] Build Docker image
- [ ] Tag release
- [ ] Create GitHub release with notes
- [ ] Update website/documentation

## Quick Commands Reference

```bash
# Check status
git status

# View changes
git diff

# View history
git log --oneline --graph

# Undo last commit (keep changes)
git reset --soft HEAD~1

# Discard local changes
git checkout -- <file>

# Pull latest changes
git pull origin main

# Push changes
git push origin main

# View remotes
git remote -v

# Create and switch to branch
git checkout -b feature/new-feature

# Switch branches
git checkout main

# Delete branch
git branch -d feature/old-feature

# Stash changes
git stash
git stash pop

# View tags
git tag -l
```

## Success! 🎉

Your repository is now set up and ready for:
- ✅ Version control
- ✅ Collaboration
- ✅ Backup and recovery
- ✅ Professional development workflow
- ✅ Open source contribution

Happy coding! 🚀
